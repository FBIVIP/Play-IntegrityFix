Telegram channel:
https://t.me/kernelsu1

https://t.me/FATAH_16

Donations
Paypal; fatehmaini18@gmail.com

binance USDT 

ID: 472220578

Tron(TRC20): TM8Tur37ErhuhGkZerNcnSdSs8v5sKNCVL


BEP20; 0x0e82d3f74b8bb693c2b4aea4b0018266cb0566f1

#19.2

- Update fingerprint.
- Android 16 support.
- WebUI improvement.
